import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

# =========================
# LOAD DATASET
# =========================

df = pd.read_csv("retail_sales.csv")

print("\n===== FIRST 5 ROWS =====")
print(df.head())

print("\n===== DATASET INFO =====")
print(df.info())

print("\n===== MISSING VALUES =====")
print(df.isnull().sum())

print("\n===== STATISTICAL SUMMARY =====")
print(df.describe())

# =========================
# DATA CLEANING
# =========================

df.drop_duplicates(inplace=True)

df.fillna(0, inplace=True)

df['Order_Date'] = pd.to_datetime(df['Order_Date'])

print("\nDataset cleaned successfully!")

# =========================
# MONTHLY SALES ANALYSIS
# =========================

monthly_sales = df.groupby(
    df['Order_Date'].dt.month
)['Sales'].sum()

plt.figure(figsize=(10, 5))
monthly_sales.plot(marker='o')
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Total Sales")
plt.grid(True)
plt.show()

# =========================
# SALES BY CATEGORY
# =========================

plt.figure(figsize=(10, 5))

category_sales = df.groupby('Category')['Sales'].sum().reset_index()

sns.barplot(
    data=category_sales,
    x='Category',
    y='Sales'
)

plt.title("Sales by Category")
plt.xlabel("Category")
plt.ylabel("Total Sales")
plt.show()

# =========================
# PROFIT VS DISCOUNT
# =========================

plt.figure(figsize=(10, 5))

sns.scatterplot(
    data=df,
    x='Discount',
    y='Profit'
)

plt.title("Profit vs Discount")
plt.xlabel("Discount")
plt.ylabel("Profit")
plt.show()

# =========================
# SALES BY REGION
# =========================

region_sales = df.groupby('Region')['Sales'].sum()

plt.figure(figsize=(10, 5))

region_sales.plot(kind='bar')

plt.title("Sales by Region")
plt.xlabel("Region")
plt.ylabel("Total Sales")
plt.show()

# =========================
# FEATURE ENGINEERING
# =========================

df['Month'] = df['Order_Date'].dt.month
df['Year'] = df['Order_Date'].dt.year

# =========================
# MACHINE LEARNING
# =========================

X = df[['Discount', 'Quantity', 'Month']]
y = df['Sales']

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

model = RandomForestRegressor(
    n_estimators=100,
    random_state=42
)

model.fit(X_train, y_train)

predictions = model.predict(X_test)

# =========================
# MODEL EVALUATION
# =========================

mae = mean_absolute_error(y_test, predictions)
r2 = r2_score(y_test, predictions)

print("\n===== MODEL RESULTS =====")
print(f"Mean Absolute Error: {mae:.2f}")
print(f"R² Score: {r2:.4f}")

# =========================
# ACTUAL VS PREDICTED
# =========================

plt.figure(figsize=(8, 6))

plt.scatter(y_test, predictions)

plt.xlabel("Actual Sales")
plt.ylabel("Predicted Sales")

plt.title("Actual vs Predicted Sales")

plt.show()

# =========================
# BUSINESS INSIGHTS
# =========================

print("\n===== BUSINESS INSIGHTS =====")

top_category = (
    df.groupby('Category')['Sales']
    .sum()
    .idxmax()
)

top_region = (
    df.groupby('Region')['Sales']
    .sum()
    .idxmax()
)

print(f"Top Selling Category: {top_category}")
print(f"Best Performing Region: {top_region}")

print("\n===== PROJECT COMPLETED SUCCESSFULLY =====")